extends Control

signal puzzle_solved
signal puzzle_closed


@onready var code_input: LineEdit = $Panel/CodeInput
@onready var message: Label = $Panel/Message

func _ready() -> void:
	# This tells the LineEdit to run your function when Enter is pressed
	code_input.text_submitted.connect(_on_text_submitted)

func _on_text_submitted(_new_text: String) -> void:
	print(code_input)
	if code_input.text == "4721":
		message.text = "Unlocked!"
		await get_tree().create_timer(2.5).timeout
		puzzle_solved.emit()
	else:
		message.text = "Wrong code!"


func _on_close_pressed() -> void:
	puzzle_closed.emit()
	queue_free()


func _on_close_puzzle_button_pressed() -> void:
	puzzle_closed.emit()
