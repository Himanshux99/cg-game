extends Node

const SAVE_PATH := "user://savegame.json"

var save_data := {
	"player": {
		"position": Vector2.ZERO
	},

	"puzzles": {},

	"objects": {}
}


func save_game(player: Node2D):
	save_data["player"]["position"] = player.global_position

	var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	file.store_string(JSON.stringify(save_data))
	print("Game Saved")
	file.close()

func load_game(player: Node2D):
	if not FileAccess.file_exists(SAVE_PATH):
		return

	var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
	var json_text = file.get_as_text()
	file.close()

	var loaded_data = JSON.parse_string(json_text)

	if loaded_data == null:
		return

	save_data = loaded_data

	player.global_position = Vector2(
		save_data["player"]["position"]["x"],
		save_data["player"]["position"]["y"]
	)


func set_puzzle_solved(puzzle_id: String):
	save_data["puzzles"][puzzle_id] = {
		"solved": true
	}


func is_puzzle_solved(puzzle_id: String) -> bool:
	if not save_data["puzzles"].has(puzzle_id):
		return false

	return save_data["puzzles"][puzzle_id]["solved"]


func set_object_state(object_id: String, state: Dictionary):
	save_data["objects"][object_id] = state


func get_object_state(object_id: String) -> Dictionary:
	return save_data["objects"].get(object_id, {})
